
mkdir build
make

